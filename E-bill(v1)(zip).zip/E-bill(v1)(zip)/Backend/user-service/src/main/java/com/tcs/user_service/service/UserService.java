package com.tcs.user_service.service;

import com.tcs.user_service.dto.LoginRequest;
import com.tcs.user_service.model.User;
import com.tcs.user_service.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.dao.DataIntegrityViolationException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User registerUser(User user) {
        // Check for existing username
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            throw new DataIntegrityViolationException("Username already exists");
        }

        // Check for existing email
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new DataIntegrityViolationException("Email already exists");
        }

        // Check for existing consumer ID
        if (user.getConsumerId() != null && userRepository.findByConsumerId(user.getConsumerId()).isPresent()) {
            throw new DataIntegrityViolationException("Consumer ID already exists");
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRegisteredAt(LocalDateTime.now().toString());
        System.out.println("Saving user: " + user); // Log user data
        return userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public boolean login(LoginRequest loginRequest) {
        Optional<User> userOptional = userRepository.findByUsername(loginRequest.getUsername());
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            boolean passwordMatches = passwordEncoder.matches(loginRequest.getPassword(), user.getPassword());
            System.out.println("Username: " + loginRequest.getUsername() + ", Password Matches: " + passwordMatches);
            return passwordMatches;
        }
        return false;
    }

    public User updateUser(String username, User updatedUser) {
        return userRepository.findByUsername(username)
            .map(existingUser -> {
                // Update only non-null fields
                if (updatedUser.getConsumerId() != null) {
                    existingUser.setConsumerId(updatedUser.getConsumerId());
                }
                if (updatedUser.getBillNumber() != null) {
                    existingUser.setBillNumber(updatedUser.getBillNumber());
                }
                if (updatedUser.getEmail() != null) {
                    existingUser.setEmail(updatedUser.getEmail());
                }
                if (updatedUser.getCustomerName() != null) {
                    existingUser.setCustomerName(updatedUser.getCustomerName());
                }
                if (updatedUser.getCountryCode() != null) {
                    existingUser.setCountryCode(updatedUser.getCountryCode());
                }
                if (updatedUser.getMobile() != null) {
                    existingUser.setMobile(updatedUser.getMobile());
                }
                return userRepository.save(existingUser);
            })
            .orElseThrow(() -> new RuntimeException("User not found"));
    }

    public boolean changePassword(String username, String currentPassword, String newPassword) {
        return userRepository.findByUsername(username)
            .map(user -> {
                if (passwordEncoder.matches(currentPassword, user.getPassword())) {
                    user.setPassword(passwordEncoder.encode(newPassword));
                    userRepository.save(user);
                    return true;
                }
                return false;
            })
            .orElse(false);
    }

    public boolean deactivateAccount(String username) {
        return userRepository.findByUsername(username)
            .map(user -> {
                user.setStatus("DEACTIVATED");
                userRepository.save(user);
                return true;
            })
            .orElse(false);
    }

    public boolean reactivateAccount(String username) {
        return userRepository.findByUsername(username)
            .map(user -> {
                user.setStatus("ACTIVE");
                userRepository.save(user);
                return true;
            })
            .orElse(false);
    }

    // Add more business logic methods as needed
} 