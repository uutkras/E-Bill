package com.tcs.user_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
@Table(name = "users", uniqueConstraints = {
    @UniqueConstraint(columnNames = "username", name = "uk_username"),
    @UniqueConstraint(columnNames = "email", name = "uk_email"),
    @UniqueConstraint(columnNames = "consumerId", name = "uk_consumer_id")
})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Username is mandatory")
    @Column(unique = true)
    private String username;

    @NotBlank(message = "Password is mandatory")
    private String password;

    @Email(message = "Email should be valid")
    @NotBlank(message = "Email is mandatory")
    @Column(unique = true)
    private String email;

    @Column(unique = true)
    private String consumerId;
    private String billNumber;
    private String customerName;
    private String countryCode;
    private String mobile;
    private String registeredAt;

    @Column(nullable = false)
    private String status = "ACTIVE";

    // Add other fields as necessary
} 