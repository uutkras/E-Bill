package com.tcs.billing_service.controller;

import com.tcs.billing_service.model.Bill;
import com.tcs.billing_service.service.BillService;
import com.tcs.billing_service.service.BillService.BillingSummary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bills")
public class BillController {

    @Autowired
    private BillService billService;

    @GetMapping
    public ResponseEntity<List<Bill>> getAllBills() {
        List<Bill> bills = billService.getAllBills();
        return ResponseEntity.ok(bills);
    }

    @GetMapping("/summary/{userId}")
    public ResponseEntity<BillingSummary> getBillingSummary(@PathVariable String userId) {
        BillingSummary summary = billService.getBillingSummary(userId);
        return ResponseEntity.ok(summary);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Bill>> getUserBills(@PathVariable String userId) {
        List<Bill> bills = billService.getUserBills(userId);
        return ResponseEntity.ok(bills);
    }

    @PostMapping("/generate/{userId}")
    public ResponseEntity<List<Bill>> generateBillsForNewUser(@PathVariable String userId) {
        List<Bill> bills = billService.generateBillsForNewUser(userId);
        return ResponseEntity.ok(bills);
    }

    @PatchMapping("/{billId}")
    public ResponseEntity<Bill> updateBillStatus(@PathVariable Long billId, @RequestBody Bill bill) {
        Bill updatedBill = billService.updateBillStatus(billId, bill.getStatus());
        return ResponseEntity.ok(updatedBill);
    }

    @PostMapping("/{billId}/pay")
    public ResponseEntity<String> payBill(@PathVariable Long billId) {
        billService.payBill(billId);
        return ResponseEntity.ok("Bill paid successfully");
    }
} 