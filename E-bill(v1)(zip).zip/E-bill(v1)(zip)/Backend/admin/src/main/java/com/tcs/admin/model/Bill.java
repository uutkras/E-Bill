package com.tcs.admin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "bills")
@NoArgsConstructor
@AllArgsConstructor
public class Bill {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String consumerId;
    private String userId;
    private BigDecimal amount;
    private LocalDate billDate;
    private LocalDate dueDate;
    private String status; // PAID, UNPAID
    private Integer unitsConsumed;
    private BigDecimal ratePerUnit;

    @Transient
    private String username;

    @Transient
    private String customerName;

    private LocalDateTime paidDate;
    private String paymentMethod;
    private String transactionId;
}