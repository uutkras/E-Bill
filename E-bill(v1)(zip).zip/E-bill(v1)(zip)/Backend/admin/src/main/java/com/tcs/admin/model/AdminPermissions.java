package com.tcs.admin.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "admin_permissions")
public class AdminPermissions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long userId;

    @Column(name = "manage_users")
    private boolean manageUsers = false;

    @Column(name = "manage_bills")
    private boolean manageBills = false;

    @Column(name = "manage_complaints")
    private boolean manageComplaints = false;

    public boolean getManageUsers() {
        return manageUsers;
    }

    public boolean getManageBills() {
        return manageBills;
    }

    public boolean getManageComplaints() {
        return manageComplaints;
    }
} 