package com.tcs.admin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "users", uniqueConstraints = {
    @UniqueConstraint(columnNames = "username", name = "uk_admin_username"),
    @UniqueConstraint(columnNames = "email", name = "uk_admin_email"),
    @UniqueConstraint(columnNames = "consumerId", name = "uk_admin_consumer_id")
})
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(unique = true)
    private String email;
    
    private String password;
    
    @Column(unique = true)
    private String consumerId;
    private String billNumber;
    private String customerName;
    private String countryCode;
    private String mobile;
    private String status = "ACTIVE"; // ACTIVE, INACTIVE, SUSPENDED, DELETED
    private LocalDateTime registeredAt;
    private LocalDateTime lastLogin;
    private LocalDateTime lastUpdated;
    
    @Column(name = "is_admin")
    private boolean admin = false;

    @ElementCollection
    @CollectionTable(name = "user_activity", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "activity")
    private List<String> activityHistory;
} 