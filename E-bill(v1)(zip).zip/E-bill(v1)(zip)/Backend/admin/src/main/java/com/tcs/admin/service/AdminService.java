package com.tcs.admin.service;

import com.tcs.admin.model.*;
import java.util.List;
import java.util.Map;

public interface AdminService {
    // Dashboard
    Map<String, Long> getDashboardStats();

    // User Management
    List<User> getAllUsers();
    User updateUserStatus(Long userId, String status);
    void deleteUser(Long userId);

    // Admin Management
    User registerAdmin(User user, Map<String, Boolean> permissions);
    AdminPermissions getAdminPermissions(Long userId);
    AdminPermissions updateAdminPermissions(Long userId, Map<String, Boolean> permissions);

    // Bill Management
    List<Bill> getAllBills();
    List<Bill> getBillsByUser(String userId);
    Bill updateBill(Long billId, Bill bill);
    void deleteBill(Long billId);

    // Payment Management
    List<Payment> getAllPayments();
    List<Payment> getPaymentsByUser(String userId);
    List<Payment> getPaymentsByBill(String billId);

    // Complaint Management
    List<Complaint> getAllComplaints();
    List<Complaint> getComplaintsByUser(String userId);
    Complaint updateComplaintStatus(Long complaintId, String status);
    Complaint updateComplaintPriority(Long complaintId, String priority);
    Complaint assignEngineer(Long complaintId, String engineerId);
    void deleteComplaint(Long complaintId);
} 