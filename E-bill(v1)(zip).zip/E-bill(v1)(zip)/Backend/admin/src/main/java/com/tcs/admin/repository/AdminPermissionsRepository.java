package com.tcs.admin.repository;

import com.tcs.admin.model.AdminPermissions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface AdminPermissionsRepository extends JpaRepository<AdminPermissions, Long> {
    Optional<AdminPermissions> findByUserId(Long userId);
} 