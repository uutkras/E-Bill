package com.tcs.admin.repository;

import com.tcs.admin.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByUserId(String userId);
    List<Payment> findByBillId(String billId);
    List<Payment> findByStatus(String status);
} 