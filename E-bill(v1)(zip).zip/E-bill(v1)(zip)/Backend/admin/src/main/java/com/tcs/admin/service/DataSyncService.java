package com.tcs.admin.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.transaction.annotation.Transactional;
import jakarta.annotation.PostConstruct;


import com.tcs.admin.repository.UserRepository;
import com.tcs.admin.repository.BillRepository;
import com.tcs.admin.repository.ComplaintRepository;
import com.tcs.admin.model.User;
import com.tcs.admin.model.Bill;
import com.tcs.admin.model.Complaint;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;
import java.util.List;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.HashMap;

@Service
@EnableScheduling
@RequiredArgsConstructor
@Slf4j
public class DataSyncService {

    private final UserRepository userRepository;
    private final BillRepository billRepository;
    private final ComplaintRepository complaintRepository;
    private final RestTemplate restTemplate;

    @Value("${user.service.url}")
    private String userServiceUrl;

    @Value("${bill.service.url}")
    private String billServiceUrl;

    @Value("${complaint.service.url}")
    private String complaintServiceUrl;

    @PostConstruct
    public void init() {
        log.info("Starting initial data sync...");
        syncData();
    }

    @Scheduled(fixedRate = 30000) // Sync every 30 seconds
    public void syncData() {
        log.info("Starting periodic data sync...");
        
        try {
            // Clear all tables first
            complaintRepository.deleteAll();
            billRepository.deleteAll();
            userRepository.deleteAll();
            log.info("Cleared all tables in admin database");

            // Then sync all data
            syncUsers();
            syncBills();
            syncComplaints();
            
            log.info("Data sync completed successfully");
        } catch (Exception e) {
            log.error("Error during data sync: {}", e.getMessage(), e);
        }
    }

    @Transactional(noRollbackFor = Exception.class)
    public void syncUsers() {
        try {
            log.info("Fetching users from: {}/api/users", userServiceUrl);
            User[] usersArray = restTemplate.getForObject(userServiceUrl + "/api/users", User[].class);
            
            if (usersArray != null && usersArray.length > 0) {
                List<User> users = Arrays.asList(usersArray);
                log.info("Received {} users from user service", users.size());
                
                for (User user : users) {
                    try {
                        if (user.getConsumerId() == null || user.getUsername() == null) {
                            log.warn("Skipping user with null consumerId or username: {}", user.getId());
                            continue;
                        }
                        
                        user.setLastUpdated(LocalDateTime.now());
                        User savedUser = userRepository.save(user);
                        log.info("Saved user - ConsumerId: {}, Username: {}", savedUser.getConsumerId(), savedUser.getUsername());
                    } catch (Exception e) {
                        log.error("Error saving user: {}", e.getMessage());
                        // Continue with next user
                    }
                }
            } else {
                log.warn("No users received from user service");
            }
        } catch (Exception e) {
            log.error("Error syncing users: {}", e.getMessage());
        }
    }

    @Transactional(noRollbackFor = Exception.class)
    public void syncBills() {
        try {
            log.info("Fetching bills from: {}/api/bills", billServiceUrl);
            Bill[] billsArray = restTemplate.getForObject(billServiceUrl + "/api/bills", Bill[].class);
            
            if (billsArray != null && billsArray.length > 0) {
                List<Bill> bills = Arrays.asList(billsArray);
                log.info("Received {} bills from bill service", bills.size());
                
                for (Bill bill : bills) {
                    try {
                        Bill savedBill = billRepository.save(bill);
                        log.info("Saved bill - ID: {}, ConsumerId: {}", savedBill.getId(), savedBill.getConsumerId());
                    } catch (Exception e) {
                        log.error("Error saving bill: {}", e.getMessage());
                        // Continue with next bill
                    }
                }
            } else {
                log.warn("No bills received from bill service");
            }
        } catch (Exception e) {
            log.error("Error syncing bills: {}", e.getMessage());
        }
    }

    @Transactional(noRollbackFor = Exception.class)
    public void syncComplaints() {
        try {
            log.info("Fetching complaints from: {}/api/complaints", complaintServiceUrl);
            Complaint[] complaintsArray = restTemplate.getForObject(complaintServiceUrl + "/api/complaints", Complaint[].class);
            
            if (complaintsArray != null && complaintsArray.length > 0) {
                List<Complaint> complaints = Arrays.asList(complaintsArray);
                log.info("Received {} complaints from complaint service", complaints.size());
                
                for (Complaint complaint : complaints) {
                    try {
                        Complaint savedComplaint = complaintRepository.save(complaint);
                        log.info("Saved complaint - ID: {}, UserId: {}", savedComplaint.getId(), savedComplaint.getUserId());
                    } catch (Exception e) {
                        log.error("Error saving complaint: {}", e.getMessage());
                        // Continue with next complaint
                    }
                }
            } else {
                log.warn("No complaints received from complaint service");
            }
        } catch (Exception e) {
            log.error("Error syncing complaints: {}", e.getMessage());
        }
    }

    // Methods to push changes to respective services
    public void pushUserUpdate(User user) {
        try {
            // User service (8080) expects PUT /api/users/{username}
            String url = userServiceUrl + "/api/users/" + user.getUsername();
            log.info("Pushing user update to: {}", url);
            
            // Remove fields that shouldn't be sent
            user.setActivityHistory(null);
            
            restTemplate.put(url, user);
            log.info("Successfully pushed user update for username: {}", user.getUsername());
        } catch (Exception e) {
            log.error("Failed to push user update for username: {}: {}", user.getUsername(), e.getMessage());
            throw new RuntimeException("Failed to sync user update with user service", e);
        }
    }

    public void pushUserDeletion(Long userId) {
        try {
            // First get the username
            User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
            
            // User service (8080) expects POST /api/users/{username}/deactivate
            String url = userServiceUrl + "/api/users/" + user.getUsername() + "/deactivate";
            log.info("Pushing user deactivation to: {}", url);
            
            restTemplate.postForObject(url, null, String.class);
            log.info("Successfully deactivated user: {}", user.getUsername());
        } catch (Exception e) {
            log.error("Failed to deactivate user ID: {}: {}", userId, e.getMessage());
            throw new RuntimeException("Failed to sync user deletion with user service", e);
        }
    }

    public void pushBillUpdate(Bill bill) {
        try {
            // Bill service (8081) expects PATCH /api/bills/{billId}
            String url = billServiceUrl + "/api/bills/" + bill.getId();
            log.info("Pushing bill update to: {}", url);
            
            Map<String, Object> request = new HashMap<>();
            request.put("status", bill.getStatus());
            request.put("amount", bill.getAmount());
            request.put("dueDate", bill.getDueDate());
            
            restTemplate.patchForObject(url, request, Bill.class);
            log.info("Successfully pushed bill update for ID: {}", bill.getId());
        } catch (Exception e) {
            log.error("Failed to push bill update for ID: {}: {}", bill.getId(), e.getMessage());
            throw new RuntimeException("Failed to sync bill update with billing service", e);
        }
    }

    public void pushBillDeletion(Long billId) {
        try {
            // Bill service (8081) expects DELETE /api/bills/{billId}
            String url = billServiceUrl + "/api/bills/" + billId;
            log.info("Pushing bill deletion to: {}", url);
            
            restTemplate.delete(url);
            log.info("Successfully pushed bill deletion for ID: {}", billId);
        } catch (Exception e) {
            log.error("Failed to push bill deletion for ID: {}: {}", billId, e.getMessage());
            throw new RuntimeException("Failed to sync bill deletion with billing service", e);
        }
    }

    public void pushComplaintUpdate(Complaint complaint) {
        try {
            // Complaint service (8082) expects PATCH /api/complaints/{complaintId}/status
            String url = complaintServiceUrl + "/api/complaints/" + complaint.getId() + "/status";
            log.info("Pushing complaint update to: {}", url);
            
            Map<String, String> request = new HashMap<>();
            request.put("status", complaint.getStatus());
            
            restTemplate.patchForObject(url, request, Complaint.class);
            log.info("Successfully pushed complaint update for ID: {}", complaint.getId());
            
            // If priority changed, update that too
            if (complaint.getPriority() != null) {
                url = complaintServiceUrl + "/api/complaints/" + complaint.getId() + "/priority";
                request = new HashMap<>();
                request.put("priority", complaint.getPriority());
                restTemplate.patchForObject(url, request, Complaint.class);
                log.info("Successfully pushed complaint priority update for ID: {}", complaint.getId());
            }
            
            // If engineer assigned, update that too
            if (complaint.getEngineerId() != null) {
                url = complaintServiceUrl + "/api/complaints/" + complaint.getId() + "/engineer";
                request = new HashMap<>();
                request.put("engineerId", complaint.getEngineerId());
                restTemplate.patchForObject(url, request, Complaint.class);
                log.info("Successfully pushed complaint engineer assignment for ID: {}", complaint.getId());
            }
        } catch (Exception e) {
            log.error("Failed to push complaint update for ID: {}: {}", complaint.getId(), e.getMessage());
            throw new RuntimeException("Failed to sync complaint update with complaint service", e);
        }
    }

    public void pushComplaintDeletion(Long complaintId) {
        try {
            // Complaint service (8082) expects DELETE /api/complaints/{complaintId}
            String url = complaintServiceUrl + "/api/complaints/" + complaintId;
            log.info("Pushing complaint deletion to: {}", url);
            
            restTemplate.delete(url);
            log.info("Successfully pushed complaint deletion for ID: {}", complaintId);
        } catch (Exception e) {
            log.error("Failed to push complaint deletion for ID: {}: {}", complaintId, e.getMessage());
            throw new RuntimeException("Failed to sync complaint deletion with complaint service", e);
        }
    }
} 