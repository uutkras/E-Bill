package com.tcs.admin.service;

import com.tcs.admin.model.*;
import com.tcs.admin.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {
    private final UserRepository userRepository;
    private final BillRepository billRepository;
    private final ComplaintRepository complaintRepository;
    private final PaymentRepository paymentRepository;
    private final AdminPermissionsRepository adminPermissionsRepository;
    private final DataSyncService dataSyncService;

    @Override
    public Map<String, Long> getDashboardStats() {
        Map<String, Long> stats = new HashMap<>();
        stats.put("totalUsers", userRepository.count());
        stats.put("totalBills", billRepository.count());
        stats.put("totalComplaints", complaintRepository.count());
        stats.put("totalPayments", paymentRepository.count());
        return stats;
    }

    // User Management
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    @Transactional
    public User updateUserStatus(Long userId, String status) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        user.setStatus(status);
        User savedUser = userRepository.save(user);
        dataSyncService.pushUserUpdate(savedUser);
        return savedUser;
    }

    @Override
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
        dataSyncService.pushUserDeletion(userId);
    }

    @Override
    @Transactional
    public User registerAdmin(User user, Map<String, Boolean> permissions) {
        // Set admin-specific fields
        user.setAdmin(true);
        user.setStatus("ACTIVE");
        user.setRegisteredAt(LocalDateTime.now());

        // Save the user first
        User savedUser = userRepository.save(user);

        // Create and save admin permissions
        AdminPermissions adminPermissions = new AdminPermissions();
        adminPermissions.setUserId(savedUser.getId());
        adminPermissions.setManageUsers(permissions.getOrDefault("manageUsers", false));
        adminPermissions.setManageBills(permissions.getOrDefault("manageBills", false));
        adminPermissions.setManageComplaints(permissions.getOrDefault("manageComplaints", false));
        adminPermissionsRepository.save(adminPermissions);

        return savedUser;
    }

    @Override
    public AdminPermissions getAdminPermissions(Long userId) {
        return adminPermissionsRepository.findByUserId(userId)
            .orElseThrow(() -> new RuntimeException("Admin permissions not found"));
    }

    @Override
    @Transactional
    public AdminPermissions updateAdminPermissions(Long userId, Map<String, Boolean> permissions) {
        AdminPermissions adminPermissions = adminPermissionsRepository.findByUserId(userId)
            .orElseThrow(() -> new RuntimeException("Admin permissions not found"));

        adminPermissions.setManageUsers(permissions.getOrDefault("manageUsers", adminPermissions.getManageUsers()));
        adminPermissions.setManageBills(permissions.getOrDefault("manageBills", adminPermissions.getManageBills()));
        adminPermissions.setManageComplaints(permissions.getOrDefault("manageComplaints", adminPermissions.getManageComplaints()));

        return adminPermissionsRepository.save(adminPermissions);
    }

    // Bill Management
    @Override
    public List<Bill> getAllBills() {
        List<Bill> bills = billRepository.findAll();
        enrichBillsWithUserInfo(bills);
        return bills;
    }

    @Override
    public List<Bill> getBillsByUser(String userId) {
        List<Bill> bills = billRepository.findByUserId(userId);
        enrichBillsWithUserInfo(bills);
        return bills;
    }

    private void enrichBillsWithUserInfo(List<Bill> bills) {
        System.out.println("Enriching " + bills.size() + " bills with user info");
        for (Bill bill : bills) {
            System.out.println("Looking up user for bill consumerId: " + bill.getConsumerId());
            Optional<User> user = userRepository.findByConsumerId(bill.getConsumerId());
            if (user.isPresent()) {
                System.out.println("Found user: " + user.get().getCustomerName());
                bill.setCustomerName(user.get().getCustomerName());
                bill.setUsername(user.get().getUsername());
            } else {
                System.out.println("No user found for consumerId: " + bill.getConsumerId());
            }
        }
    }

    @Override
    @Transactional
    public Bill updateBill(Long billId, Bill bill) {
        Bill existingBill = billRepository.findById(billId)
            .orElseThrow(() -> new RuntimeException("Bill not found"));
        existingBill.setAmount(bill.getAmount());
        existingBill.setDueDate(bill.getDueDate());
        existingBill.setStatus(bill.getStatus());
        Bill savedBill = billRepository.save(existingBill);
        dataSyncService.pushBillUpdate(savedBill);
        return savedBill;
    }

    @Override
    public void deleteBill(Long billId) {
        billRepository.deleteById(billId);
        dataSyncService.pushBillDeletion(billId);
    }

    // Payment Management
    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public List<Payment> getPaymentsByUser(String userId) {
        return paymentRepository.findAll().stream()
            .filter(payment -> payment.getUserId().equals(userId))
            .toList();
    }

    @Override
    public List<Payment> getPaymentsByBill(String billId) {
        return paymentRepository.findAll().stream()
            .filter(payment -> payment.getBillId().equals(billId))
            .toList();
    }

    // Complaint Management
    @Override
    public List<Complaint> getAllComplaints() {
        List<Complaint> complaints = complaintRepository.findAll();
        enrichComplaintsWithUserInfo(complaints);
        return complaints;
    }

    @Override
    public List<Complaint> getComplaintsByUser(String userId) {
        List<Complaint> complaints = complaintRepository.findByUserId(userId);
        enrichComplaintsWithUserInfo(complaints);
        return complaints;
    }

    private void enrichComplaintsWithUserInfo(List<Complaint> complaints) {
        System.out.println("Enriching " + complaints.size() + " complaints with user info");
        for (Complaint complaint : complaints) {
            System.out.println("Looking up user for complaint userId: " + complaint.getUserId());
            Optional<User> user = userRepository.findByConsumerId(complaint.getUserId());
            if (user.isPresent()) {
                System.out.println("Found user: " + user.get().getCustomerName());
                complaint.setCustomerName(user.get().getCustomerName());
                complaint.setUsername(user.get().getUsername());
            } else {
                System.out.println("No user found for userId: " + complaint.getUserId());
            }
        }
    }

    @Override
    @Transactional
    public Complaint updateComplaintStatus(Long complaintId, String status) {
        Complaint complaint = complaintRepository.findById(complaintId)
            .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setStatus(status);
        Complaint savedComplaint = complaintRepository.save(complaint);
        dataSyncService.pushComplaintUpdate(savedComplaint);
        return savedComplaint;
    }

    @Override
    @Transactional
    public Complaint updateComplaintPriority(Long complaintId, String priority) {
        Complaint complaint = complaintRepository.findById(complaintId)
            .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setPriority(priority);
        Complaint savedComplaint = complaintRepository.save(complaint);
        dataSyncService.pushComplaintUpdate(savedComplaint);
        return savedComplaint;
    }

    @Override
    @Transactional
    public Complaint assignEngineer(Long complaintId, String engineerId) {
        Complaint complaint = complaintRepository.findById(complaintId)
            .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setEngineerId(engineerId);
        complaint.setAssignedAt(LocalDateTime.now().toString());
        Complaint savedComplaint = complaintRepository.save(complaint);
        dataSyncService.pushComplaintUpdate(savedComplaint);
        return savedComplaint;
    }

    @Override
    @Transactional
    public void deleteComplaint(Long complaintId) {
        complaintRepository.deleteById(complaintId);
        dataSyncService.pushComplaintDeletion(complaintId);
    }
} 