package com.tcs.complaint_service.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "complaints")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Complaint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String complaintId;
    private String userId;
    private String userName;
    private String billNumber;
    private String mobileNumber;
    private String address;
    
    private String complaintType;
    private String subType;
    private String problemTitle;
    private String problemDescription;
    
    @Enumerated(EnumType.STRING)
    private ComplaintStatus status;
    
    @Enumerated(EnumType.STRING)
    private Priority priority;
    
    private String assignedTo;
    private LocalDateTime expectedResolution;
    private LocalDateTime createdAt;
    private LocalDateTime lastUpdated;
    
    @ElementCollection
    @CollectionTable(name = "complaint_comments", joinColumns = @JoinColumn(name = "complaint_id"))
    @Column(name = "comment")
    private List<String> comments;
} 