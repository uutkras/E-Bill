import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './components/shared/shared.module';
import { AdminModule } from './components/admin/admin.module';
import { WelcomeModule } from './components/welcome/welcome.module';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/auth/login/login.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { ViewBillComponent } from './components/billing/view-bill/view-bill.component';
import { PayBillComponent } from './components/billing/pay-bill/pay-bill.component';
import { PaymentSuccessComponent } from './components/billing/payment-success/payment-success.component';
import { AcknowledgementComponent } from './components/auth/acknowledgement/acknowledgement.component';
import { RegisterComplaintsComponent } from './components/complaints/register-complaints/register-complaints.component';
import { ComplaintStatusComponent } from './components/complaints/complaint-status/complaint-status.component';
import { UserProfileComponent } from './components/user/user-profile/user-profile.component';
import { AdminRegistrationComponent } from './components/admin/admin-registration/admin-registration.component';

import { AuthService } from './services/auth.service';
import { AuthGuard } from './guards/auth.guard';
import { AuthInterceptor } from './interceptors/auth.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ViewBillComponent,
    PayBillComponent,
    PaymentSuccessComponent,
    AcknowledgementComponent,
    RegisterComplaintsComponent,
    ComplaintStatusComponent,
    UserProfileComponent,
    AdminRegistrationComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    CommonModule,
    SharedModule,
    AdminModule,
    WelcomeModule,
    AppRoutingModule
  ],
  providers: [
    AuthService,
    AuthGuard,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
