import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { UserService } from '../../../services/user.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  profileForm: FormGroup;
  currentUser: any;
  loading = false;
  error: string | null = null;
  successMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private userService: UserService,
    private router: Router
  ) {
    this.profileForm = this.fb.group({
      customerName: ['', [Validators.required, Validators.pattern('^[A-Za-z\\s]{2,50}$')]],
      email: ['', [Validators.required, Validators.email]],
      countryCode: ['+91', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern('^[6-9][0-9]{9}$')]],
      currentPassword: [''],
      newPassword: [''],
      confirmNewPassword: ['']
    });
  }

  ngOnInit() {
    this.currentUser = this.authService.getCurrentUser();
    if (!this.currentUser) {
      this.router.navigate(['/login']);
      return;
    }

    this.loadUserProfile();
  }

  loadUserProfile() {
    this.loading = true;
    this.userService.getUserProfile(this.currentUser.userId).subscribe({
      next: (userData: User) => {
        this.profileForm.patchValue({
          customerName: userData.customerName,
          email: userData.email,
          countryCode: userData.countryCode || '+91',
          mobile: userData.mobile
        });
        this.loading = false;
      },
      error: (err: Error) => {
        console.error('Error loading profile:', err);
        this.error = 'Failed to load profile data';
        this.loading = false;
      }
    });
  }

  onSubmit() {
    if (this.profileForm.valid) {
      this.loading = true;
      this.error = null;
      this.successMessage = null;

      const updatedProfile = {
        ...this.profileForm.value,
        userId: this.currentUser.userId
      };

      this.userService.updateProfile(updatedProfile).subscribe({
        next: () => {
          this.successMessage = 'Profile updated successfully';
          this.loading = false;
        },
        error: (err: Error) => {
          console.error('Error updating profile:', err);
          this.error = 'Failed to update profile';
          this.loading = false;
        }
      });
    }
  }

  changePassword() {
    const { currentPassword, newPassword, confirmNewPassword } = this.profileForm.value;
    
    if (!currentPassword || !newPassword || !confirmNewPassword) {
      this.error = 'Please fill all password fields';
      return;
    }

    if (newPassword !== confirmNewPassword) {
      this.error = 'New passwords do not match';
      return;
    }

    this.loading = true;
    this.error = null;
    this.successMessage = null;

    this.userService.changePassword({
      userId: this.currentUser.userId,
      currentPassword,
      newPassword
    }).subscribe({
      next: () => {
        this.successMessage = 'Password changed successfully';
        this.profileForm.patchValue({
          currentPassword: '',
          newPassword: '',
          confirmNewPassword: ''
        });
        this.loading = false;
      },
      error: (err: Error) => {
        console.error('Error changing password:', err);
        this.error = err.message || 'Failed to change password';
        this.loading = false;
      }
    });
  }

  deactivateAccount() {
    if (confirm('Are you sure you want to deactivate your account? You can reactivate it later by contacting support.')) {
      this.loading = true;
      this.error = null;

      this.userService.deactivateAccount(this.currentUser.username).subscribe({
        next: () => {
          this.successMessage = 'Account deactivated successfully.';
          this.loading = false;
          this.currentUser.status = 'DEACTIVATED';
          localStorage.setItem('user', JSON.stringify(this.currentUser));
          this.authService.logout();
        },
        error: (err: Error) => {
          this.error = 'Failed to deactivate account. Please try again.';
          this.loading = false;
          console.error('Error deactivating account:', err);
        },
        complete: () => {
          this.router.navigate(['/login']);
        }
      });
    }
  }
} 