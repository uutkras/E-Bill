import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';
import { LoginCredentials } from '../../../models/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  loginError = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const credentials: LoginCredentials = {
        userId: this.loginForm.get('username')?.value,
        password: this.loginForm.get('password')?.value
      };

      this.authService.login(credentials).subscribe({
        next: (response) => {
          if (response && response.success) {
            console.log('Login successful');
            this.router.navigate(['/welcome']);
          } else {
            this.loginError = true;
            this.errorMessage = response.message || 'Login failed';
            console.log('Login failed:', response.message || 'Unknown error');
          }
        },
        error: (error) => {
          this.loginError = true;
          this.errorMessage = error.message || 'An error occurred';
          console.error('Login error:', error);
        }
      });
    } else {
      console.log('Form is invalid:', this.loginForm.errors);
    }
  }
}
