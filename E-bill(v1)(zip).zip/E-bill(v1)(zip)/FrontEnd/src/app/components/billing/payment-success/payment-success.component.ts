import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { BillService, Bill } from '../../../services/bill.service';
import { finalize } from 'rxjs/operators';

@Component({
  selector: 'app-payment-success',
  templateUrl: './payment-success.component.html',
  styleUrls: ['./payment-success.component.css']
})
export class PaymentSuccessComponent implements OnInit {
  paymentAmount: number = 0;
  transactionId: string = '';
  paymentDate: Date = new Date();
  customerName: string = '';

  constructor(
    private router: Router,
    private authService: AuthService,
    private billService: BillService
  ) {
    // Generate random transaction ID
    this.transactionId = 'TXN' + Math.random().toString(36).substr(2, 9).toUpperCase();
  }

  ngOnInit() {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      this.router.navigate(['/login']);
      return;
    }
    this.customerName = currentUser.customerName || 'Guest';

    // Get stored payment data
    const paymentData = this.billService.getStoredPaymentData();
    if (paymentData) {
      this.paymentAmount = paymentData.totalAmount;
      this.paymentDate = new Date(paymentData.timestamp);

      // Try updating all bills at once first
      this.billService.payBills(paymentData.bills).subscribe({
        next: (updatedBills) => {
          console.log('All bills updated successfully:', updatedBills);
          this.billService.clearPaymentData();
          setTimeout(() => {
            this.router.navigate(['/invoice']);
          }, 2000);
        },
        error: (error) => {
          console.error('Error updating bills:', error);
          // If bulk update fails, try updating individually
          this.updateBillsIndividually(paymentData.bills);
        }
      });
    } else {
      this.router.navigate(['/view-bill']);
    }
  }

  private updateBillsIndividually(bills: Bill[]) {
    console.log('Attempting to update bills individually');
    let successCount = 0;
    let failureCount = 0;

    bills.forEach(bill => {
      this.billService.updateBillStatus(bill.id, 'PAID')
        .pipe(finalize(() => {
          console.log(`Finished updating bill ${bill.id}`);
          // Check if all bills have been processed
          if (successCount + failureCount === bills.length) {
            if (failureCount === 0) {
              console.log('All bills updated successfully');
              this.billService.clearPaymentData();
              this.router.navigate(['/invoice']);
            } else {
              console.error(`${failureCount} bills failed to update`);
              alert(`${failureCount} bills could not be marked as paid. Please contact support.`);
              this.router.navigate(['/view-bill']);
            }
          }
        }))
        .subscribe({
          next: (updatedBill) => {
            console.log(`Bill ${bill.id} updated successfully:`, updatedBill);
            successCount++;
          },
          error: (error) => {
            console.error(`Error updating bill ${bill.id}:`, error);
            failureCount++;
          }
        });
    });
  }

  downloadInvoice() {
    const invoice = document.createElement('a');
    const content = `
      WE Energy - Payment Receipt
      -------------------------
      Transaction ID: ${this.transactionId}
      Date: ${this.paymentDate.toLocaleString()}
      Customer Name: ${this.customerName}
      Amount Paid: ₹${this.paymentAmount}
      Status: Payment Successful
      -------------------------
      Thank you for your payment!
    `;
    
    const blob = new Blob([content], { type: 'text/plain' });
    invoice.href = window.URL.createObjectURL(blob);
    invoice.download = `Invoice_${this.transactionId}.txt`;
    invoice.click();
  }

  goToHome() {
    this.router.navigate(['/welcome']);
  }
}
