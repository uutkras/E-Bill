import { Component, OnInit } from '@angular/core';
import { BillService, Bill } from '../../../services/bill.service';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-bill',
  templateUrl: './view-bill.component.html',
  styleUrls: ['./view-bill.component.css']
})
export class ViewBillComponent implements OnInit {
  bills: Bill[] = [];
  selectedBills: Bill[] = [];
  totalSelectedAmount: number = 0;
  loading = true;
  error: string | null = null;

  constructor(
    private billService: BillService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadBills();
  }

  loadBills(): void {
    this.loading = true;
    this.error = null;
    
    const currentUser = this.authService.getCurrentUser();
    console.log('Current User:', currentUser);

    if (!currentUser) {
      this.error = 'Please log in to view your bills';
      this.loading = false;
      return;
    }

    if (!currentUser.consumerId) {
      this.error = 'Consumer ID not found. Please check your profile details.';
      console.error('Missing Consumer ID:', currentUser);
      this.loading = false;
      return;
    }

    // Use consumerId to fetch bills
    this.billService.getBillsForUser(currentUser.consumerId).subscribe({
      next: (bills) => {
        console.log('Received bills:', bills);
        this.bills = bills;
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading bills:', error);
        if (error.status === 404) {
          this.generateBills(currentUser.consumerId);
        } else {
          this.error = 'Failed to load bills. Please try again later.';
          this.loading = false;
        }
      }
    });
  }

  toggleBillSelection(bill: Bill): void {
    const index = this.selectedBills.findIndex(b => b.id === bill.id);
    if (index === -1) {
      this.selectedBills.push(bill);
    } else {
      this.selectedBills.splice(index, 1);
    }
    this.updateTotalAmount();
  }

  isBillSelected(bill: Bill): boolean {
    return this.selectedBills.some(b => b.id === bill.id);
  }

  updateTotalAmount(): void {
    this.totalSelectedAmount = this.selectedBills.reduce((sum, bill) => sum + bill.amount, 0);
  }

  paySelectedBills(): void {
    if (this.selectedBills.length === 0) {
      this.error = 'Please select at least one bill to pay';
      return;
    }
    
    // Store payment data for other pages
    this.billService.storePaymentData(this.selectedBills, this.totalSelectedAmount);
    
    // Navigate to payment page
    this.router.navigate(['/pay-bill']);
  }

  generateBills(userId: string): void {
    console.log('Starting bill generation for user:', userId);
    this.error = null;
    this.loading = true;

    this.billService.generateBillsForNewUser(userId).subscribe({
      next: (bills) => {
        console.log('Successfully generated bills:', bills);
        if (bills && bills.length > 0) {
          this.bills = bills;
        } else {
          this.error = 'No bills were generated. Please try again.';
        }
        this.loading = false;
      },
      error: (error) => {
        console.error('Error generating bills:', error);
        this.error = `Failed to generate bills: ${error.error?.message || error.message || 'Unknown error'}`;
        this.loading = false;
      }
    });
  }

  formatDate(date: string): string {
    return new Date(date).toLocaleDateString();
  }

  toggleSelectAll(event: any): void {
    const isChecked = event.target.checked;
    const unpaidBills = this.bills.filter(b => b.status !== 'PAID');
    
    if (isChecked) {
      // Select all unpaid bills
      unpaidBills.forEach(bill => {
        if (!this.isBillSelected(bill)) {
          this.toggleBillSelection(bill);
        }
      });
    } else {
      // Deselect all bills
      this.selectedBills = [];
      this.updateTotalAmount();
    }
  }

  areAllUnpaidBillsSelected(): boolean {
    const unpaidBills = this.bills.filter(b => b.status !== 'PAID');
    return unpaidBills.length > 0 && unpaidBills.every(bill => this.isBillSelected(bill));
  }

  markBillsAsPaid(bills: Bill[]): void {
    this.loading = true;
    this.error = null;

    this.billService.payBills(bills).subscribe({
      next: (updatedBills) => {
        console.log('Bills marked as paid:', updatedBills);
        // Refresh the bills list
        this.loadBills();
        // Clear selected bills
        this.selectedBills = [];
        this.updateTotalAmount();
      },
      error: (error) => {
        console.error('Error updating bill status:', error);
        this.error = 'Failed to update bill status. Please try again.';
        this.loading = false;
      }
    });
  }
}
