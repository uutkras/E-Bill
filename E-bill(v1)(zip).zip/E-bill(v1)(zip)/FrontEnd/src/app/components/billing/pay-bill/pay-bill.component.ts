import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BillService } from '../../../services/bill.service';

interface ValidationResult {
  [key: string]: boolean;
}

type PaymentMode = 'credit' | 'debit' | 'netbanking' | 'upi';

@Component({
  selector: 'app-pay-bill',
  templateUrl: './pay-bill.component.html',
  styleUrls: ['./pay-bill.component.css']
})
export class PayBillComponent implements OnInit {
  paymentForm: FormGroup;
  paymentAmount: number = 0;
  selectedPaymentMode: string = 'credit';
  months: string[] = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
  years: number[] = [];
  banks: string[] = [
    'State Bank of India',
    'HDFC Bank',
    'ICICI Bank',
    'Axis Bank',
    'Punjab National Bank'
  ];

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private billService: BillService
  ) {
    // Generate next 10 years
    const currentYear = new Date().getFullYear();
    this.years = Array.from({length: 10}, (_, i) => currentYear + i);

    this.paymentForm = this.fb.group({
      paymentMode: ['credit', Validators.required],
      cardNumber: ['', [Validators.pattern('^[0-9]{16}$')]],
      expiryMonth: ['', []],
      expiryYear: ['', []],
      cvv: ['', [Validators.pattern('^[0-9]{3}$')]],
      cardholderName: ['', [Validators.pattern('^[a-zA-Z ]*$')]],
      bank: [''],
      upiId: ['', [Validators.pattern('^[a-zA-Z0-9.-]{2,256}@[a-zA-Z][a-zA-Z]{2,64}$')]]
    });

    // Update validators based on payment mode
    this.paymentForm.get('paymentMode')?.valueChanges.subscribe(mode => {
      this.selectedPaymentMode = mode;
      this.updateValidators();
    });
  }

  ngOnInit(): void {
    // Get stored payment data
    const paymentData = this.billService.getStoredPaymentData();
    if (paymentData) {
      this.paymentAmount = paymentData.totalAmount;
    } else {
      // If no payment data, redirect back to view-bill
      this.router.navigate(['/view-bill']);
    }
  }

  updateValidators(): void {
    const cardFields = ['cardNumber', 'expiryMonth', 'expiryYear', 'cvv', 'cardholderName'];
    const bankFields = ['bank'];
    const upiFields = ['upiId'];

    if (this.selectedPaymentMode === 'credit' || this.selectedPaymentMode === 'debit') {
      cardFields.forEach(field => {
        this.paymentForm.get(field)?.setValidators([Validators.required]);
      });
      bankFields.concat(upiFields).forEach(field => {
        this.paymentForm.get(field)?.clearValidators();
      });
    } else if (this.selectedPaymentMode === 'netbanking') {
      bankFields.forEach(field => {
        this.paymentForm.get(field)?.setValidators([Validators.required]);
      });
      cardFields.concat(upiFields).forEach(field => {
        this.paymentForm.get(field)?.clearValidators();
      });
    } else if (this.selectedPaymentMode === 'upi') {
      upiFields.forEach(field => {
        this.paymentForm.get(field)?.setValidators([Validators.required]);
      });
      cardFields.concat(bankFields).forEach(field => {
        this.paymentForm.get(field)?.clearValidators();
      });
    }

    this.paymentForm.updateValueAndValidity();
  }

  formatCardNumber(event: any): void {
    let value = event.target.value.replace(/\s/g, '');
    if (value.length > 0) {
      value = value.match(new RegExp('.{1,4}', 'g')).join(' ');
    }
    event.target.value = value;
  }

  validateName() {
    return (control: any): ValidationResult | null => {
      const value = control.value;
      if (!value) return null;

      const words = value.trim().split(/\s+/);
      
      if (words.length < 3) {
        return { minWords: true };
      }

      if (words.every((word: string) => word.toLowerCase() === words[0].toLowerCase())) {
        return { sameName: true };
      }

      return null;
    };
  }

  getErrorMessage(fieldName: string): string {
    const control = this.paymentForm.get(fieldName);
    if (control?.hasError('required')) {
      return `${fieldName.charAt(0).toUpperCase() + fieldName.slice(1)} is required`;
    }
    if (control?.hasError('pattern')) {
      switch (fieldName) {
        case 'cardNumber':
          return 'Please enter a valid 16-digit card number';
        case 'cvv':
          return 'Please enter a valid 3-digit CVV';
        case 'cardholderName':
          return 'Please enter a valid name (letters only)';
        case 'upiId':
          return 'Please enter a valid UPI ID';
        default:
          return 'Invalid input';
      }
    }
    return '';
  }

  onSubmit(): void {
    if (this.paymentForm.valid) {
      // Navigate to payment success page
      this.router.navigate(['/payment-success']);
    }
  }

  onCancel(): void {
    // Clear stored payment data
    this.billService.clearPaymentData();
    // Navigate back to view-bill
    this.router.navigate(['/view-bill']);
  }
} 