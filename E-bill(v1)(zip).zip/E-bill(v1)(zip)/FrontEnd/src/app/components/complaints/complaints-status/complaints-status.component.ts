import { Component } from '@angular/core';

@Component({
  selector: 'app-complaints-status',
  templateUrl: './complaints-status.component.html',
  styleUrls: ['./complaints-status.component.css']
})
export class ComplaintsStatusComponent {

}
