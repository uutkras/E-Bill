import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin } from 'rxjs';
import { AdminService } from '../../../services/admin.service';

interface DashboardStat {
  title: string;
  value: number;
  icon: string;
  color: string;
  route: string;
}

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  stats: DashboardStat[] = [
    { 
      title: 'Total Users', 
      value: 0, 
      icon: '👥',
      color: '#007bff',
      route: 'users'
    },
    { 
      title: 'Active Complaints', 
      value: 0, 
      icon: '⚠️',
      color: '#dc3545',
      route: 'complaints'
    },
    { 
      title: 'Pending Bills', 
      value: 0, 
      icon: '📄',
      color: '#ffc107',
      route: 'bills'
    },
    { 
      title: 'Total Revenue', 
      value: 0, 
      icon: '💰',
      color: '#28a745',
      route: ''
    }
  ];

  recentComplaints: any[] = [];
  loading = true;
  error: string | null = null;

  constructor(
    private router: Router,
    private adminService: AdminService
  ) {}

  ngOnInit() {
    this.loadDashboardData();
  }

  loadDashboardData() {
    this.loading = true;
    this.error = null;

    // Load all data in parallel
    forkJoin({
      stats: this.adminService.getDashboardStats(),
      users: this.adminService.getAllUsers(),
      complaints: this.adminService.getAllComplaints(),
      bills: this.adminService.getAllBills()
    }).subscribe({
      next: (data) => {
        // Update stats
        this.stats[0].value = data.stats.totalUsers || 0;
        this.stats[1].value = data.complaints.filter(c => 
          c.status !== 'RESOLVED' && c.status !== 'CLOSED'
        ).length;
        this.stats[2].value = data.bills.filter(b => b.status === 'UNPAID').length;
        // Calculate total revenue from all bills
        this.stats[3].value = data.bills
          .reduce((sum, b) => sum + Number(b.amount), 0);

        // Update recent activities
        this.recentComplaints = data.complaints
          .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
          .slice(0, 5);

        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading dashboard data:', err);
        this.error = 'Failed to load dashboard data. Please try again later.';
        this.loading = false;
      }
    });
  }

  navigateTo(route: string) {
    if (route) {
      this.router.navigate(['/admin/' + route]);
    }
  }

  getStatusColor(status: string): string {
    switch (status.toUpperCase()) {
      case 'OPEN':
      case 'PENDING':
        return '#ffc107'; // warning yellow
      case 'IN_PROGRESS':
        return '#17a2b8'; // info blue
      case 'RESOLVED':
      case 'COMPLETED':
      case 'PAID':
        return '#28a745'; // success green
      case 'CLOSED':
        return '#6c757d'; // secondary gray
      case 'FAILED':
      case 'REJECTED':
        return '#dc3545'; // danger red
      default:
        return '#6c757d'; // default gray
    }
  }
} 