import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../services/admin.service';

interface Bill {
  id: number;
  userId: number;
  customerName: string;
  consumerId: string;
  amount: number;
  dueDate: string;
  status: string;
  generatedAt: string;
  paidAt?: string;
}

@Component({
  selector: 'app-manage-bills',
  templateUrl: './manage-bills.component.html',
  styleUrls: ['./manage-bills.component.css']
})
export class ManageBillsComponent implements OnInit {
  bills: Bill[] = [];
  loading = true;
  error: string | null = null;
  searchTerm = '';
  statusFilter = 'ALL';
  
  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.loadBills();
  }

  loadBills() {
    this.loading = true;
    this.error = null;

    this.adminService.getAllBills().subscribe({
      next: (data) => {
        this.bills = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading bills:', err);
        this.error = 'Failed to load bills. Please try again later.';
        this.loading = false;
      }
    });
  }

  updateBillStatus(billId: number, newStatus: string) {
    this.adminService.updateBill(billId, newStatus).subscribe({
      next: (updatedBill) => {
        this.bills = this.bills.map(bill => 
          bill.id === billId ? { ...bill, status: newStatus } : bill
        );
      },
      error: (err) => {
        console.error('Error updating bill status:', err);
        this.error = 'Failed to update bill status. Please try again.';
      }
    });
  }

  deleteBill(billId: number) {
    if (confirm('Are you sure you want to delete this bill?')) {
      // Assuming there's a deleteBill method in AdminService
      this.adminService.deleteBill(billId).subscribe({
        next: () => {
          this.bills = this.bills.filter(bill => bill.id !== billId);
        },
        error: (err) => {
          console.error('Error deleting bill:', err);
          this.error = 'Failed to delete bill. Please try again.';
        }
      });
    }
  }

  get filteredBills() {
    return this.bills
      .filter(bill => 
        (bill.customerName?.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
         bill.consumerId?.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
         bill.amount.toString().includes(this.searchTerm))
      )
      .filter(bill => this.statusFilter === 'ALL' || bill.status === this.statusFilter);
  }

  getStatusColor(status: string): string {
    switch (status.toUpperCase()) {
      case 'PAID':
        return '#28a745';
      case 'PENDING':
        return '#ffc107';
      case 'OVERDUE':
        return '#dc3545';
      default:
        return '#6c757d';
    }
  }

  formatAmount(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  isOverdue(dueDate: string): boolean {
    return new Date(dueDate) < new Date();
  }

  openDbConsole() {
    window.open('http://localhost:8081/h2-console', '_blank');
  }
} 