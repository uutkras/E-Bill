import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../services/admin.service';

interface User {
  id: number;
  username: string;
  email: string;
  customerName: string;
  consumerId: string;
  mobile: string;
  status: string;
  registeredAt: string;
}

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit {
  users: User[] = [];
  loading = true;
  error: string | null = null;
  searchTerm = '';
  
  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    this.loading = true;
    this.error = null;

    this.adminService.getAllUsers().subscribe({
      next: (data) => {
        this.users = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading users:', err);
        this.error = 'Failed to load users. Please try again later.';
        this.loading = false;
      }
    });
  }

  updateUserStatus(userId: number, newStatus: string) {
    this.adminService.updateUserStatus(userId, newStatus).subscribe({
      next: (updatedUser) => {
        this.users = this.users.map(user => 
          user.id === userId ? { ...user, status: newStatus } : user
        );
      },
      error: (err) => {
        console.error('Error updating user status:', err);
        this.error = 'Failed to update user status. Please try again.';
      }
    });
  }

  deleteUser(userId: number) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.adminService.deleteUser(userId).subscribe({
        next: () => {
          this.users = this.users.filter(user => user.id !== userId);
        },
        error: (err) => {
          console.error('Error deleting user:', err);
          this.error = 'Failed to delete user. Please try again.';
        }
      });
    }
  }

  get filteredUsers() {
    return this.users.filter(user => 
      user.username.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      user.customerName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      user.consumerId.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  getStatusColor(status: string): string {
    switch (status.toUpperCase()) {
      case 'ACTIVE':
        return '#28a745';
      case 'INACTIVE':
        return '#dc3545';
      case 'SUSPENDED':
        return '#ffc107';
      default:
        return '#6c757d';
    }
  }

  openDbConsole() {
    window.open('http://localhost:8080/h2-console', '_blank');
  }
} 