import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-registration',
  templateUrl: './admin-registration.component.html',
  styleUrls: ['./admin-registration.component.css']
})
export class AdminRegistrationComponent implements OnInit {
  registrationForm: FormGroup;
  loading = false;
  error: string | null = null;
  successMessage: string | null = null;

  constructor(
    private fb: FormBuilder,
    private adminService: AdminService,
    private router: Router
  ) {
    this.registrationForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(5)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [
        Validators.required,
        Validators.minLength(8),
        Validators.pattern('^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')
      ]],
      confirmPassword: ['', Validators.required],
      role: ['ADMIN', Validators.required],
      permissions: this.fb.group({
        manageUsers: [true],
        manageBills: [true],
        manageComplaints: [true]
      })
    }, { validators: this.passwordMatchValidator });
  }

  ngOnInit() {
    // Check if current user has admin privileges
    if (!this.adminService.hasAdminPrivileges()) {
      this.router.navigate(['/admin/dashboard']);
    }
  }

  passwordMatchValidator(form: FormGroup) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { mismatch: true };
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      this.loading = true;
      this.error = null;
      this.successMessage = null;

      const adminData = {
        ...this.registrationForm.value,
        isAdmin: true,
        status: 'ACTIVE',
        registeredAt: new Date().toISOString()
      };

      this.adminService.registerAdmin(adminData).subscribe({
        next: () => {
          this.successMessage = 'Admin user registered successfully';
          this.registrationForm.reset({
            role: 'ADMIN',
            permissions: {
              manageUsers: true,
              manageBills: true,
              manageComplaints: true
            }
          });
          this.loading = false;
        },
        error: (err) => {
          console.error('Error registering admin:', err);
          this.error = err.error?.message || 'Failed to register admin user';
          this.loading = false;
        }
      });
    } else {
      Object.keys(this.registrationForm.controls).forEach(key => {
        const control = this.registrationForm.get(key);
        if (control?.invalid) {
          control.markAsTouched();
        }
      });
    }
  }

  getErrorMessage(controlName: string): string {
    const control = this.registrationForm.get(controlName);
    if (control?.errors && control.touched) {
      if (control.errors['required']) return `${controlName} is required`;
      if (control.errors['email']) return 'Invalid email format';
      if (control.errors['minlength']) {
        return `Minimum ${control.errors['minlength'].requiredLength} characters required`;
      }
      if (control.errors['pattern']) {
        if (controlName === 'password') {
          return 'Password must include uppercase, lowercase, number and special character';
        }
        return 'Invalid format';
      }
      if (control.errors['mismatch']) {
        return 'Passwords do not match';
      }
    }
    return '';
  }
} 