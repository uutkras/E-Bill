import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../services/admin.service';

interface Complaint {
  id: number;
  userId: number;
  problemTitle: string;
  problemDescription: string;
  status: string;
  priority: string;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
  comments: string[];
}

@Component({
  selector: 'app-manage-complaints',
  templateUrl: './manage-complaints.component.html',
  styleUrls: ['./manage-complaints.component.css']
})
export class ManageComplaintsComponent implements OnInit {
  complaints: Complaint[] = [];
  loading = true;
  error: string | null = null;
  searchTerm = '';
  statusFilter = 'ALL';
  priorityFilter = 'ALL';
  
  constructor(private adminService: AdminService) {}

  ngOnInit() {
    this.loadComplaints();
  }

  loadComplaints() {
    this.loading = true;
    this.error = null;

    this.adminService.getAllComplaints().subscribe({
      next: (data) => {
        this.complaints = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading complaints:', err);
        this.error = 'Failed to load complaints. Please try again later.';
        this.loading = false;
      }
    });
  }

  updateComplaintStatus(complaintId: number, newStatus: string) {
    this.adminService.updateComplaintStatus(complaintId, newStatus).subscribe({
      next: () => {
        this.complaints = this.complaints.map(complaint => 
          complaint.id === complaintId ? { ...complaint, status: newStatus } : complaint
        );
      },
      error: (err) => {
        console.error('Error updating complaint status:', err);
        this.error = 'Failed to update complaint status. Please try again.';
      }
    });
  }

  updateComplaintPriority(complaintId: number, newPriority: string) {
    this.adminService.updateComplaintPriority(complaintId, newPriority).subscribe({
      next: () => {
        this.complaints = this.complaints.map(complaint => 
          complaint.id === complaintId ? { ...complaint, priority: newPriority } : complaint
        );
      },
      error: (err) => {
        console.error('Error updating complaint priority:', err);
        this.error = 'Failed to update complaint priority. Please try again.';
      }
    });
  }

  assignEngineer(complaintId: number, engineerId: string) {
    this.adminService.assignEngineer(complaintId, engineerId).subscribe({
      next: () => {
        this.complaints = this.complaints.map(complaint => 
          complaint.id === complaintId ? { ...complaint, assignedTo: engineerId } : complaint
        );
      },
      error: (err) => {
        console.error('Error assigning engineer:', err);
        this.error = 'Failed to assign engineer. Please try again.';
      }
    });
  }

  deleteComplaint(complaintId: number) {
    if (confirm('Are you sure you want to delete this complaint?')) {
      this.adminService.deleteComplaint(complaintId).subscribe({
        next: () => {
          this.complaints = this.complaints.filter(complaint => complaint.id !== complaintId);
        },
        error: (err) => {
          console.error('Error deleting complaint:', err);
          this.error = 'Failed to delete complaint. Please try again.';
        }
      });
    }
  }

  get filteredComplaints() {
    return this.complaints
      .filter(complaint => 
        (complaint.problemTitle?.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
         complaint.problemDescription?.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
         complaint.id.toString().includes(this.searchTerm))
      )
      .filter(complaint => this.statusFilter === 'ALL' || complaint.status === this.statusFilter)
      .filter(complaint => this.priorityFilter === 'ALL' || complaint.priority === this.priorityFilter);
  }

  getStatusColor(status: string): string {
    switch (status.toUpperCase()) {
      case 'RESOLVED':
        return '#28a745';
      case 'IN_PROGRESS':
        return '#ffc107';
      case 'PENDING':
        return '#dc3545';
      default:
        return '#6c757d';
    }
  }

  getPriorityColor(priority: string): string {
    switch (priority.toUpperCase()) {
      case 'HIGH':
        return '#dc3545';
      case 'MEDIUM':
        return '#ffc107';
      case 'LOW':
        return '#28a745';
      default:
        return '#6c757d';
    }
  }

  openDbConsole() {
    window.open('http://localhost:8082/h2-console', '_blank');
  }
} 