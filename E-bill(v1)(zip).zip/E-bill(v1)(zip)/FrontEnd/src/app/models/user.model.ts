export interface User {
    id?: number;
    username: string;
    password: string;
    email: string;
    consumerId: string;
    billNumber: string;
    customerName: string;
    countryCode: string;
    mobileNumber: string;
    mobile?: string;  // For backward compatibility
    registeredAt?: string;
    userId: string;
    isAdmin?: boolean;
    status?: string;
}

export interface LoginCredentials {
    userId: string;
    password: string;
} 