export interface Complaint {
  id: number;
  userId: string;
  problemTitle: string;
  problemDescription: string;
  status: string;
  priority: string;
  assignedTo?: string;
  createdAt: string;
  updatedAt: string;
  comments?: string[];
  // Add other fields as necessary
} 