export interface Bill {
  id: number;
  consumerId: string;
  amount: number;
  billDate: string;
  dueDate: string;
  status: 'PAID' | 'UNPAID';
  unitsConsumed: number;
  ratePerUnit: number;
  // Add other fields as necessary
} 