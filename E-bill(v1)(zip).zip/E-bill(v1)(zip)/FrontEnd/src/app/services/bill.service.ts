import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, forkJoin, throwError } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';

export interface Bill {
  id: number;
  consumerId: string;
  userId: string;
  amount: number;
  billDate: string;
  dueDate: string;
  status: string;
  unitsConsumed: number;
  ratePerUnit: number;
}

export interface BillingSummary {
  totalBills: number;
  totalAmount: number;
  paidAmount: number;
  unpaidAmount: number;
}

@Injectable({
  providedIn: 'root'
})
export class BillService {
  private apiUrl = 'http://localhost:8081/api/bills';

  constructor(private http: HttpClient) { }

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });
  }

  private handleError(error: HttpErrorResponse) {
    console.error('An error occurred:', error);
    return throwError(() => new Error(error.error?.message || 'An error occurred while processing your request'));
  }

  getBillsForUser(userId: string): Observable<Bill[]> {
    console.log('Fetching bills for user:', userId);
    return this.http.get<Bill[]>(`${this.apiUrl}/user/${userId}`, {
      headers: this.getHeaders()
    }).pipe(
      tap(bills => console.log('Received bills:', bills)),
      catchError(this.handleError)
    );
  }

  getBillingSummary(userId: string): Observable<BillingSummary> {
    console.log('Fetching billing summary for user:', userId);
    return this.http.get<BillingSummary>(`${this.apiUrl}/summary/${userId}`, {
      headers: this.getHeaders()
    }).pipe(
      tap(summary => console.log('Received billing summary:', summary)),
      catchError(this.handleError)
    );
  }

  generateBillsForNewUser(userId: string): Observable<Bill[]> {
    console.log('Generating bills for user:', userId);
    return this.http.post<Bill[]>(`${this.apiUrl}/generate/${userId}`, null, {
      headers: this.getHeaders()
    }).pipe(
      tap(bills => console.log('Generated bills:', bills)),
      catchError(this.handleError)
    );
  }

  updateBillStatus(billId: number, status: string): Observable<Bill> {
    console.log(`Updating bill ${billId} status to ${status}`);
    return this.http.patch<Bill>(`${this.apiUrl}/${billId}`, { status }, {
      headers: this.getHeaders()
    }).pipe(
      tap(updatedBill => {
        console.log('Updated bill status:', updatedBill);
      }),
      catchError(this.handleError)
    );
  }

  payBills(bills: Bill[]): Observable<Bill[]> {
    console.log('Paying bills:', bills);
    if (!bills || bills.length === 0) {
      return throwError(() => new Error('No bills provided for payment'));
    }

    const billIds = bills.map(bill => bill.id);
    const body = {
      billIds: billIds,
      status: 'PAID',
      paymentDate: new Date().toISOString()
    };

    return this.http.post<Bill[]>(`${this.apiUrl}/pay-multiple`, body, {
      headers: this.getHeaders()
    }).pipe(
      tap(updatedBills => {
        console.log('All bills updated:', updatedBills);
        if (!updatedBills || updatedBills.length !== bills.length) {
          throw new Error('Not all bills were updated successfully');
        }
        const unpaidBills = updatedBills.filter(bill => bill.status !== 'PAID');
        if (unpaidBills.length > 0) {
          throw new Error(`Failed to update status for bills: ${unpaidBills.map(b => b.id).join(', ')}`);
        }
      }),
      catchError(this.handleError)
    );
  }

  storePaymentData(bills: Bill[], totalAmount: number): void {
    try {
      sessionStorage.setItem('selectedBills', JSON.stringify(bills));
      sessionStorage.setItem('totalAmount', totalAmount.toString());
      sessionStorage.setItem('paymentTimestamp', new Date().toISOString());
      console.log('Payment data stored successfully');
    } catch (error) {
      console.error('Error storing payment data:', error);
      throw error;
    }
  }

  getStoredPaymentData(): { bills: Bill[], totalAmount: number, timestamp: string } | null {
    try {
      const billsStr = sessionStorage.getItem('selectedBills');
      const amountStr = sessionStorage.getItem('totalAmount');
      const timestamp = sessionStorage.getItem('paymentTimestamp');

      if (!billsStr || !amountStr || !timestamp) {
        console.log('No payment data found in session storage');
        return null;
      }

      const data = {
        bills: JSON.parse(billsStr),
        totalAmount: parseFloat(amountStr),
        timestamp: timestamp
      };
      console.log('Retrieved payment data:', data);
      return data;
    } catch (error) {
      console.error('Error retrieving payment data:', error);
      return null;
    }
  }

  clearPaymentData(): void {
    try {
      sessionStorage.removeItem('selectedBills');
      sessionStorage.removeItem('totalAmount');
      sessionStorage.removeItem('paymentTimestamp');
      console.log('Payment data cleared successfully');
    } catch (error) {
      console.error('Error clearing payment data:', error);
      throw error;
    }
  }
}
