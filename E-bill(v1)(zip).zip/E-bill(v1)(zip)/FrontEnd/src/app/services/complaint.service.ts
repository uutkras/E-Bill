import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Complaint } from '../models/complaint.model';

@Injectable({
  providedIn: 'root'
})
export class ComplaintService {
  private apiUrl = 'http://localhost:8082/api/complaints';

  constructor(private http: HttpClient) { }

  registerComplaint(complaint: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, complaint);
  }

  getComplaints(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
  }

  getComplaintsByUser(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/user/${userId}`);
  }

  updateComplaintStatus(complaintId: number, status: string): Observable<any> {
    return this.http.patch<any>(`${this.apiUrl}/${complaintId}/status`, { status });
  }

  addComment(complaintId: number, comment: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/${complaintId}/comments`, { comment });
  }

  deleteComplaint(complaintId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${complaintId}`);
  }
}
