import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private apiUrl = `${environment.apiUrl}/users`;

  constructor(private http: HttpClient) { }

  register(user: User): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/register`, user);
  }

  getUserProfile(userId: string): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/${userId}`);
  }

  updateProfile(user: Partial<User>): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/${user.userId}`, user);
  }

  changePassword(data: { userId: string; currentPassword: string; newPassword: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/${data.userId}/change-password`, {
      currentPassword: data.currentPassword,
      newPassword: data.newPassword
    });
  }

  deactivateAccount(userId: string): Observable<any> {
    // Get current user from localStorage to get the username
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return this.http.post(`${this.apiUrl}/${user.username}/deactivate`, {});
  }

  // Add more methods as needed
} 