import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

export interface DashboardStats {
  totalUsers: number;
  activeComplaints: number;
  pendingBills: number;
  totalRevenue: number;
  recentComplaints: any[];
  recentPayments: any[];
}

export interface User {
  userId: string;
  customerName: string;
  email: string;
  mobileNumber: string;
  billNumber: string;
  registeredAt: string;
  status: 'Active' | 'Inactive';
}

export interface Bill {
  billId: string;
  userId: string;
  customerName: string;
  amount: number;
  dueDate: string;
  status: 'Paid' | 'Unpaid' | 'Overdue';
  generatedDate: string;
  paidDate?: string;
}

export interface Payment {
  paymentId: string;
  billId: string;
  userId: string;
  customerName: string;
  amount: number;
  paymentDate: string;
  paymentMethod: string;
  status: 'Success' | 'Failed' | 'Pending';
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = environment.adminApiUrl;

  constructor(private http: HttpClient) {}

  // Dashboard
  getDashboardStats(): Observable<any> {
    return this.http.get(`${this.apiUrl}/dashboard/stats`);
  }

  // Users
  getAllUsers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/users`);
  }

  updateUserStatus(userId: number, status: string): Observable<any> {
    return this.http.patch(`${this.apiUrl}/users/${userId}/status`, { status });
  }

  deleteUser(userId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/users/${userId}`);
  }

  hasAdminPrivileges(): boolean {
    // This should check the current user's admin status
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    return user.isAdmin === true;
  }

  registerAdmin(adminData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, adminData);
  }

  // Bills
  getAllBills(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/bills`);
  }

  getUserBills(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/users/${userId}/bills`);
  }

  updateBill(billId: number, bill: any): Observable<any> {
    return this.http.patch(`${this.apiUrl}/bills/${billId}`, bill);
  }

  deleteBill(billId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/bills/${billId}`);
  }

  // Complaints
  getAllComplaints(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/complaints`);
  }

  getUserComplaints(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/users/${userId}/complaints`);
  }

  updateComplaintStatus(complaintId: number, status: string): Observable<any> {
    return this.http.patch(`${this.apiUrl}/complaints/${complaintId}/status`, { status });
  }

  updateComplaintPriority(complaintId: number, priority: string): Observable<any> {
    return this.http.patch(`${this.apiUrl}/complaints/${complaintId}/priority`, { priority });
  }

  assignEngineer(complaintId: number, engineerId: string): Observable<any> {
    return this.http.patch(`${this.apiUrl}/complaints/${complaintId}/engineer`, { engineerId });
  }

  deleteComplaint(complaintId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/complaints/${complaintId}`);
  }

  // Payments
  getAllPayments(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/payments`);
  }

  getUserPayments(userId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/users/${userId}/payments`);
  }

  getBillPayments(billId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/bills/${billId}/payments`);
  }
} 