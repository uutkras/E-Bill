import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { tap, map, catchError, switchMap } from 'rxjs/operators';
import { User, LoginCredentials } from '../models/user.model';

interface LoginResponseBody {
  id: number;
  username: string;
  password: string;
  email: string;
  consumerId: string;
  billNumber: string;
  customerName: string;
  countryCode: string;
  mobile: string;
  registeredAt: string;
  isAdmin?: boolean;
}

interface LoginResponse {
  success: boolean;
  user?: User;
  message?: string;
  token?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly ADMIN_CREDENTIALS = {
    userId: 'uutkrasadmin',
    password: 'uutkrasadmin'
  };

  private apiUrl = `${environment.apiUrl}/users`;

  constructor(private http: HttpClient) {
    // Initialize users array if it doesn't exist
    if (!localStorage.getItem('users')) {
      localStorage.setItem('users', JSON.stringify([]));
    }
  }

  login(credentials: LoginCredentials): Observable<LoginResponse> {
    console.log('Login attempt with:', credentials);
    const loginRequest = {
      username: credentials.userId,
      password: credentials.password
    };
    
    return this.http.post<LoginResponseBody>(`${this.apiUrl}/login`, loginRequest, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }).pipe(
      map(response => {
        console.log('Login response:', response);
        // If we get a response with a username, consider it successful
        if (response && response.username) {
          const user: User = {
            userId: response.username,
            username: response.username,
            password: credentials.password,
            email: response.email || '',
            consumerId: response.consumerId || '',
            billNumber: response.billNumber || '',
            customerName: response.customerName || '',
            countryCode: response.countryCode || '',
            mobileNumber: response.mobile || '',
            isAdmin: response.isAdmin || false
          };
          localStorage.setItem('user', JSON.stringify(user));
          return {
            success: true,
            user: user,
            message: 'Login successful'
          };
        }
        return {
          success: false,
          message: 'Invalid credentials'
        };
      }),
      catchError(error => {
        console.error('Login error:', error);
        return of({
          success: false,
          message: error.status === 401 ? 'Invalid credentials' : 'An error occurred during login'
        });
      })
    );
  }

  private fetchUserDetails(username: string): void {
    this.http.get<User>(`${this.apiUrl}/${username}`).subscribe({
      next: (userDetails) => {
        console.log('Retrieved user details:', userDetails);
        const currentUser = this.getCurrentUser();
        if (currentUser) {
          const updatedUser: User = {
            ...currentUser,
            consumerId: userDetails.consumerId || '',
            billNumber: userDetails.billNumber || '',
            email: userDetails.email || '',
            customerName: userDetails.customerName || username,
            countryCode: userDetails.countryCode || '',
            mobileNumber: userDetails.mobileNumber || ''
          };
          localStorage.setItem('user', JSON.stringify(updatedUser));
          console.log('Updated user data with details:', updatedUser);
        }
      },
      error: (error) => {
        console.error('Error fetching user details:', error);
      }
    });
  }

  private getUserDetails(username: string): Observable<User> {
    return this.http.get<User>(`${environment.apiUrl}/users/${username}`, {
      headers: new HttpHeaders({
        'Accept': 'application/json'
      }),
      withCredentials: true
    });
  }

  register(user: User): Observable<boolean> {
    console.log('Registering user:', user);
    
    const registrationRequest = {
      username: user.username,
      password: user.password,
      email: user.email,
      consumerId: user.consumerId,
      billNumber: user.billNumber,
      customerName: user.customerName,
      countryCode: user.countryCode,
      mobile: user.mobileNumber
    };
    
    console.log('Sending registration request:', registrationRequest);
    
    return this.http.post(`${this.apiUrl}/register`, registrationRequest, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }).pipe(
      map(response => {
        console.log('Registration response:', response);
        const storedUser = {
          ...user,
          userId: user.username
        };
        localStorage.setItem('user', JSON.stringify(storedUser));
        return true;
      }),
      catchError(error => {
        console.error('Registration error:', error);
        return of(false);
      })
    );
  }

  updateUser(username: string, updates: Partial<User>): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/${username}`, updates).pipe(
      tap(updatedUser => {
        // Update local storage with new user data
        localStorage.setItem('user', JSON.stringify(updatedUser));
      }),
      catchError(error => {
        console.error('Error updating user:', error);
        throw error;
      })
    );
  }

  getCurrentUser(): User | null {
    const userStr = localStorage.getItem('user');
    if (!userStr) {
      return null;
    }

    try {
      const user = JSON.parse(userStr);
      console.log('Retrieved user data:', user);
      return user;
    } catch (error) {
      console.error('Error parsing user data:', error);
      return null;
    }
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.isAdmin || false;
  }

  logout(): void {
    localStorage.removeItem('user');
    // Also clear any other stored user data
    localStorage.removeItem('users');
  }

  // Helper method to check registration status
  checkRegistrationStatus(): void {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    console.log('Current registered users:', users);
  }
}
