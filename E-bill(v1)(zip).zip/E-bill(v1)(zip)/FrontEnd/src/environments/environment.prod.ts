export const environment = {
  production: true,
  apiUrl: 'http://your-production-url/api' // Update with your production URL
}; 