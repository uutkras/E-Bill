package com.tcs.complaint_service.service;

import com.tcs.complaint_service.model.Complaint;
import com.tcs.complaint_service.model.ComplaintStatus;
import com.tcs.complaint_service.model.Priority;
import com.tcs.complaint_service.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository complaintRepository;

    private final Random random = new Random();

    private final String[] SUPPORT_AGENTS = {
        "Rajesh Kumar (Field Engineer)",
        "Priya Sharma (Technical Support)",
        "Amit Patel (Senior Technician)",
        "Deepika Singh (Customer Service)",
        "Suresh Verma (Maintenance Specialist)"
    };

    public Complaint createComplaint(String userId, String userName, String billNumber, 
            String mobileNumber, String address, String complaintType, String subType, 
            String problemTitle, String problemDescription) {
        
        Complaint complaint = new Complaint();
        
        // Set basic info
        complaint.setComplaintId("COMP" + System.currentTimeMillis());
        complaint.setUserId(userId);
        complaint.setUserName(userName);
        complaint.setBillNumber(billNumber);
        complaint.setMobileNumber(mobileNumber);
        complaint.setAddress(address);
        
        // Set complaint details
        complaint.setComplaintType(complaintType);
        complaint.setSubType(subType);
        complaint.setProblemTitle(problemTitle);
        complaint.setProblemDescription(problemDescription);
        
        // Set automated fields
        complaint.setStatus(ComplaintStatus.PENDING);
        complaint.setPriority(getRandomPriority());
        complaint.setAssignedTo(SUPPORT_AGENTS[random.nextInt(SUPPORT_AGENTS.length)]);
        complaint.setCreatedAt(LocalDateTime.now());
        complaint.setLastUpdated(LocalDateTime.now());
        complaint.setExpectedResolution(calculateExpectedResolution());
        complaint.setComments(new ArrayList<>());

        return complaintRepository.save(complaint);
    }

    public List<Complaint> getComplaintsByUserId(String userId) {
        return complaintRepository.findByUserId(userId);
    }

    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

    public Complaint updateComplaintStatus(Long id, ComplaintStatus newStatus) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        
        complaint.setStatus(newStatus);
        complaint.setLastUpdated(LocalDateTime.now());
        
        if (newStatus == ComplaintStatus.RESOLVED) {
            String resolution = String.format("Issue has been resolved by %s", complaint.getAssignedTo());
            complaint.getComments().add(resolution);
        }
        
        return complaintRepository.save(complaint);
    }

    public Complaint addComment(Long id, String comment) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Complaint not found"));
        
        complaint.getComments().add(comment);
        complaint.setLastUpdated(LocalDateTime.now());
        
        return complaintRepository.save(complaint);
    }

    public void deleteComplaint(Long id) {
        complaintRepository.deleteById(id);
    }

    private Priority getRandomPriority() {
        return Priority.values()[random.nextInt(Priority.values().length)];
    }

    private LocalDateTime calculateExpectedResolution() {
        // Random resolution time between 1 to 5 days
        int daysToAdd = random.nextInt(5) + 1;
        return LocalDateTime.now().plusDays(daysToAdd);
    }
} 