package com.tcs.complaint_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
