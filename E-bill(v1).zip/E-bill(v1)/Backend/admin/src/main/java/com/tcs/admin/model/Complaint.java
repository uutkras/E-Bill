package com.tcs.admin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Entity
@Table(name = "complaints")
@NoArgsConstructor
@AllArgsConstructor
public class Complaint {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String complaintId;
    private String userId;
    private String username;
    private String billNumber;
    private String mobileNumber;
    private String address;
    
    private String complaintType;
    private String subType;
    private String problemTitle;
    private String problemDescription;
    private String status; // OPEN, IN_PROGRESS, RESOLVED, CLOSED
    private String priority; // LOW, MEDIUM, HIGH, URGENT
    private String assignedTo;
    private LocalDateTime expectedResolution;
    private LocalDateTime createdAt;
    private LocalDateTime lastUpdated;
    
    @Transient
    private String customerName;
    
    @ElementCollection
    @CollectionTable(name = "complaint_comments", joinColumns = @JoinColumn(name = "complaint_id"))
    @Column(name = "comment")
    private List<String> comments;
} 