package com.tcs.billing_service.service;

import com.tcs.billing_service.model.Bill;
import com.tcs.billing_service.repository.BillRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;

@Service
public class BillService {
    
    @Autowired
    private BillRepository billRepository;

    public List<Bill> getAllBills() {
        return billRepository.findAll();
    }

    public List<Bill> generateBillsForNewUser(String userId) {
        System.out.println("Generating bills for user: " + userId);
        // First check if bills already exist
        List<Bill> existingBills = getUserBills(userId);
        if (!existingBills.isEmpty()) {
            System.out.println("Bills already exist for user: " + userId);
            return existingBills;
        }

        List<Bill> bills = new ArrayList<>();
        LocalDate currentDate = LocalDate.now();

        // Generate bills for past 12 months
        for (int i = 11; i >= 0; i--) {
            LocalDate billDate = currentDate.minusMonths(i);
            // Use the same ID for both userId and consumerId since we don't have the consumer ID
            Bill bill = new Bill(userId, userId, billDate);
            
            // Mark older bills as paid (except last 2 months)
            if (i > 1) {
                bill.setStatus("PAID");
            }
            
            bills.add(bill);
        }

        List<Bill> savedBills = billRepository.saveAll(bills);
        System.out.println("Generated and saved " + savedBills.size() + " bills for user: " + userId);
        return savedBills;
    }

    public List<Bill> getUserBills(String userId) {
        System.out.println("Searching for bills with userId or consumerId: " + userId);
        
        // Try finding by userId first
        List<Bill> billsByUserId = billRepository.findByUserIdOrderByBillDateDesc(userId);
        System.out.println("Found " + billsByUserId.size() + " bills by userId: " + userId);
        
        // If no bills found by userId, try by consumerId
        if (billsByUserId.isEmpty()) {
            List<Bill> billsByConsumerId = billRepository.findByConsumerIdOrderByBillDateDesc(userId);
            System.out.println("Found " + billsByConsumerId.size() + " bills by consumerId: " + userId);
            return billsByConsumerId;
        }
        
        return billsByUserId;
    }

    public Bill getBillById(Long billId) {
        return billRepository.findById(billId)
            .orElseThrow(() -> new RuntimeException("Bill not found"));
    }

    public void payBill(Long billId) {
        Bill bill = getBillById(billId);
        bill.setStatus("PAID");
        billRepository.save(bill);
    }

    public BillingSummary getBillingSummary(String userId) {
        // Get bills using either userId or consumerId
        List<Bill> allBills = billRepository.findByUserIdOrConsumerIdOrderByBillDateDesc(userId);
        
        // Calculate totals manually from the bills
        BigDecimal totalBilled = BigDecimal.ZERO;
        BigDecimal totalPaid = BigDecimal.ZERO;
        BigDecimal totalUnpaid = BigDecimal.ZERO;
        
        for (Bill bill : allBills) {
            totalBilled = totalBilled.add(bill.getAmount());
            if ("PAID".equals(bill.getStatus())) {
                totalPaid = totalPaid.add(bill.getAmount());
            } else {
                totalUnpaid = totalUnpaid.add(bill.getAmount());
            }
        }
        
        return new BillingSummary(
            (long) allBills.size(),
            totalBilled,
            totalPaid,
            totalUnpaid
        );
    }

    public Bill updateBillStatus(Long billId, String status) {
        System.out.println("Updating bill " + billId + " status to " + status);
        Bill bill = getBillById(billId);
        bill.setStatus(status);
        Bill updatedBill = billRepository.save(bill);
        System.out.println("Updated bill status successfully");
        return updatedBill;
    }

    // Inner class for billing summary
    public static class BillingSummary {
        private final Long totalBills;
        private final BigDecimal totalAmount;
        private final BigDecimal paidAmount;
        private final BigDecimal unpaidAmount;

        public BillingSummary(Long totalBills, BigDecimal totalAmount, BigDecimal paidAmount, BigDecimal unpaidAmount) {
            this.totalBills = totalBills;
            this.totalAmount = totalAmount;
            this.paidAmount = paidAmount;
            this.unpaidAmount = unpaidAmount;
        }

        public Long getTotalBills() {
            return totalBills;
        }

        public BigDecimal getTotalAmount() {
            return totalAmount;
        }

        public BigDecimal getPaidAmount() {
            return paidAmount;
        }

        public BigDecimal getUnpaidAmount() {
            return unpaidAmount;
        }
    }
} 