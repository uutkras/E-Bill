package com.tcs.billing_service.repository;

import com.tcs.billing_service.model.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.math.BigDecimal;

@Repository
public interface BillRepository extends JpaRepository<Bill, Long> {
    List<Bill> findByConsumerIdOrderByBillDateDesc(String consumerId);
    List<Bill> findByUserIdOrderByBillDateDesc(String userId);
    
    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.userId = ?1 AND b.status = 'UNPAID'")
    BigDecimal getTotalUnpaidAmountByUserId(String userId);
    
    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.userId = ?1")
    BigDecimal getTotalBilledAmountByUserId(String userId);
    
    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.userId = ?1 AND b.status = 'PAID'")
    BigDecimal getTotalPaidAmountByUserId(String userId);
    
    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.consumerId = ?1 AND b.status = 'UNPAID'")
    BigDecimal getTotalUnpaidAmount(String consumerId);
    
    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.consumerId = ?1")
    BigDecimal getTotalBilledAmount(String consumerId);
    
    @Query("SELECT SUM(b.amount) FROM Bill b WHERE b.consumerId = ?1 AND b.status = 'PAID'")
    BigDecimal getTotalPaidAmount(String consumerId);

    @Query("SELECT b FROM Bill b WHERE b.userId = ?1 OR b.consumerId = ?1 ORDER BY b.billDate DESC")
    List<Bill> findByUserIdOrConsumerIdOrderByBillDateDesc(String id);
} 