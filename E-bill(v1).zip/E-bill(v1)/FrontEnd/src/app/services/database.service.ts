import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {
  private readonly dbConsoles = {
    users: 'http://localhost:8080/h2-console',    // User Service
    bills: 'http://localhost:8081/h2-console',    // Bill Service
    complaints: 'http://localhost:8082/h2-console' // Complaint Service
  };

  openDbConsole(service: 'users' | 'bills' | 'complaints'): void {
    const url = this.dbConsoles[service];
    window.open(url, '_blank');
  }
} 