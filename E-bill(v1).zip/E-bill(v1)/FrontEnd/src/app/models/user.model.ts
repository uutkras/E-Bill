export interface User {
    id?: number;
    username: string;
    password: string;
    email: string;
    consumerId: string;
    billNumber: string;
    customerName: string;
    countryCode: string;
    mobileNumber: string;
    registeredAt?: string;
    userId: string;
    isAdmin?: boolean;
}

export interface LoginCredentials {
    userId: string;
    password: string;
} 