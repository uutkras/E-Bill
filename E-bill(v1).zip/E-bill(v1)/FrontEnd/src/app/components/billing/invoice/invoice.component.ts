import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import { BillService, Bill } from '../../../services/bill.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  bills: Bill[] = [];
  totalAmount: number = 0;
  paymentDate: Date = new Date();
  customerName: string = '';
  transactionId: string = '';

  constructor(
    private router: Router,
    private authService: AuthService,
    private billService: BillService
  ) {
    // Generate random transaction ID
    this.transactionId = 'TXN' + Math.random().toString(36).substr(2, 9).toUpperCase();
  }

  ngOnInit() {
    const currentUser = this.authService.getCurrentUser();
    if (!currentUser) {
      this.router.navigate(['/login']);
      return;
    }
    this.customerName = currentUser.customerName || 'Guest';

    // Get stored payment data
    const paymentData = this.billService.getStoredPaymentData();
    if (paymentData) {
      this.bills = paymentData.bills;
      this.totalAmount = paymentData.totalAmount;
      this.paymentDate = new Date(paymentData.timestamp);
    } else {
      this.router.navigate(['/view-bill']);
    }
  }

  downloadInvoice() {
    const invoice = document.createElement('a');
    const content = `
      WE Energy - Payment Receipt
      -------------------------
      Transaction ID: ${this.transactionId}
      Date: ${this.paymentDate.toLocaleString()}
      Customer Name: ${this.customerName}
      
      Bill Details:
      ${this.bills.map(bill => `
        Bill Date: ${new Date(bill.billDate).toLocaleDateString()}
        Due Date: ${new Date(bill.dueDate).toLocaleDateString()}
        Amount: ₹${bill.amount}
        Status: Paid
        -------------------------
      `).join('\n')}
      
      Total Amount Paid: ₹${this.totalAmount}
      Status: Payment Successful
      -------------------------
      Thank you for your payment!
    `;
    
    const blob = new Blob([content], { type: 'text/plain' });
    invoice.href = window.URL.createObjectURL(blob);
    invoice.download = `Invoice_${this.transactionId}.txt`;
    invoice.click();
  }

  goToHome() {
    this.router.navigate(['/welcome']);
  }
}
