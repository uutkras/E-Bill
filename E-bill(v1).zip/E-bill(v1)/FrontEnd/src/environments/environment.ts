export const environment = {
  production: false,
  apiUrl: 'http://localhost:8080/api',
  adminApiUrl: 'http://localhost:8083/api/admin',
  billApiUrl: 'http://localhost:8081/api/bills',
  complaintApiUrl: 'http://localhost:8082/api/complaints'
}; 