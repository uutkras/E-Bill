package com.tcs.admin.model;

import lombok.Getter;
import lombok.AllArgsConstructor;

@Getter
@AllArgsConstructor
public enum UserStatus {
    ACTIVE("Active"),
    INACTIVE("Inactive");

    private final String displayName;
} 