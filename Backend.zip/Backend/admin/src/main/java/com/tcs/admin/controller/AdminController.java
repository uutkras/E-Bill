package com.tcs.admin.controller;

import com.tcs.admin.model.*;
import com.tcs.admin.service.AdminService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {
    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    // Dashboard
    @GetMapping("/dashboard/stats")
    public ResponseEntity<Map<String, Long>> getDashboardStats() {
        return ResponseEntity.ok(adminService.getDashboardStats());
    }

    // Users
    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(adminService.getAllUsers());
    }

    @PatchMapping("/users/{userId}/status")
    public ResponseEntity<User> updateUserStatus(
        @PathVariable Long userId,
        @RequestBody Map<String, String> request
    ) {
        String status = request.get("status").toUpperCase();
        return ResponseEntity.ok(adminService.updateUserStatus(userId, status));
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId) {
        adminService.deleteUser(userId);
        return ResponseEntity.ok().build();
    }

    // Bills
    @GetMapping("/bills")
    public ResponseEntity<List<Bill>> getAllBills() {
        return ResponseEntity.ok(adminService.getAllBills());
    }

    @GetMapping("/users/{userId}/bills")
    public ResponseEntity<List<Bill>> getBillsByUser(@PathVariable String userId) {
        return ResponseEntity.ok(adminService.getBillsByUser(userId));
    }

    @PatchMapping("/bills/{billId}")
    public ResponseEntity<Bill> updateBill(
        @PathVariable Long billId,
        @RequestBody Bill bill
    ) {
        return ResponseEntity.ok(adminService.updateBill(billId, bill));
    }

    @DeleteMapping("/bills/{billId}")
    public ResponseEntity<Void> deleteBill(@PathVariable Long billId) {
        adminService.deleteBill(billId);
        return ResponseEntity.ok().build();
    }

    // Payments
    @GetMapping("/payments")
    public ResponseEntity<List<Payment>> getAllPayments() {
        return ResponseEntity.ok(adminService.getAllPayments());
    }

    @GetMapping("/users/{userId}/payments")
    public ResponseEntity<List<Payment>> getPaymentsByUser(@PathVariable String userId) {
        return ResponseEntity.ok(adminService.getPaymentsByUser(userId));
    }

    @GetMapping("/bills/{billId}/payments")
    public ResponseEntity<List<Payment>> getPaymentsByBill(@PathVariable String billId) {
        return ResponseEntity.ok(adminService.getPaymentsByBill(billId));
    }

    // Complaints
    @GetMapping("/complaints")
    public ResponseEntity<List<Complaint>> getAllComplaints() {
        return ResponseEntity.ok(adminService.getAllComplaints());
    }

    @GetMapping("/users/{userId}/complaints")
    public ResponseEntity<List<Complaint>> getComplaintsByUser(@PathVariable String userId) {
        return ResponseEntity.ok(adminService.getComplaintsByUser(userId));
    }

    @PatchMapping("/complaints/{complaintId}/status")
    public ResponseEntity<Complaint> updateComplaintStatus(
        @PathVariable Long complaintId,
        @RequestBody Map<String, String> request
    ) {
        String status = request.get("status").toUpperCase().replace(" ", "_");
        return ResponseEntity.ok(adminService.updateComplaintStatus(complaintId, status));
    }

    @PatchMapping("/complaints/{complaintId}/priority")
    public ResponseEntity<Complaint> updateComplaintPriority(
        @PathVariable Long complaintId,
        @RequestBody Map<String, String> request
    ) {
        String priority = request.get("priority").toUpperCase();
        return ResponseEntity.ok(adminService.updateComplaintPriority(complaintId, priority));
    }

    @PatchMapping("/complaints/{complaintId}/engineer")
    public ResponseEntity<Complaint> assignEngineer(
        @PathVariable Long complaintId,
        @RequestBody Map<String, String> request
    ) {
        String engineerId = request.get("engineerId");
        return ResponseEntity.ok(adminService.assignEngineer(complaintId, engineerId));
    }

    @DeleteMapping("/complaints/{complaintId}")
    public ResponseEntity<Void> deleteComplaint(@PathVariable Long complaintId) {
        adminService.deleteComplaint(complaintId);
        return ResponseEntity.ok().build();
    }
} 