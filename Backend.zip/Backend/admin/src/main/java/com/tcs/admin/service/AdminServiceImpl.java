package com.tcs.admin.service;

import com.tcs.admin.model.*;
import com.tcs.admin.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {
    private final UserRepository userRepository;
    private final BillRepository billRepository;
    private final ComplaintRepository complaintRepository;
    private final PaymentRepository paymentRepository;

    @Override
    public Map<String, Long> getDashboardStats() {
        Map<String, Long> stats = new HashMap<>();
        stats.put("totalUsers", userRepository.count());
        stats.put("totalBills", billRepository.count());
        stats.put("totalComplaints", complaintRepository.count());
        stats.put("totalPayments", paymentRepository.count());
        return stats;
    }

    // User Management
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    @Transactional
    public User updateUserStatus(Long userId, String status) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found"));
        user.setStatus(status);
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }

    // Bill Management
    @Override
    public List<Bill> getAllBills() {
        List<Bill> bills = billRepository.findAll();
        enrichBillsWithUserInfo(bills);
        return bills;
    }

    @Override
    public List<Bill> getBillsByUser(String userId) {
        List<Bill> bills = billRepository.findByUserId(userId);
        enrichBillsWithUserInfo(bills);
        return bills;
    }

    private void enrichBillsWithUserInfo(List<Bill> bills) {
        System.out.println("Enriching " + bills.size() + " bills with user info");
        for (Bill bill : bills) {
            System.out.println("Looking up user for bill consumerId: " + bill.getConsumerId());
            Optional<User> user = userRepository.findByConsumerId(bill.getConsumerId());
            if (user.isPresent()) {
                System.out.println("Found user: " + user.get().getCustomerName());
                bill.setCustomerName(user.get().getCustomerName());
                bill.setUsername(user.get().getUsername());
            } else {
                System.out.println("No user found for consumerId: " + bill.getConsumerId());
            }
        }
    }

    @Override
    @Transactional
    public Bill updateBill(Long billId, Bill bill) {
        Bill existingBill = billRepository.findById(billId)
            .orElseThrow(() -> new RuntimeException("Bill not found"));
        // Update bill fields
        existingBill.setAmount(bill.getAmount());
        existingBill.setDueDate(bill.getDueDate());
        existingBill.setStatus(bill.getStatus());
        return billRepository.save(existingBill);
    }

    @Override
    public void deleteBill(Long billId) {
        billRepository.deleteById(billId);
    }

    // Payment Management
    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public List<Payment> getPaymentsByUser(String userId) {
        return paymentRepository.findByUserId(userId);
    }

    @Override
    public List<Payment> getPaymentsByBill(String billId) {
        return paymentRepository.findByBillId(billId);
    }

    // Complaint Management
    @Override
    public List<Complaint> getAllComplaints() {
        List<Complaint> complaints = complaintRepository.findAll();
        enrichComplaintsWithUserInfo(complaints);
        return complaints;
    }

    @Override
    public List<Complaint> getComplaintsByUser(String userId) {
        List<Complaint> complaints = complaintRepository.findByUserId(userId);
        enrichComplaintsWithUserInfo(complaints);
        return complaints;
    }

    private void enrichComplaintsWithUserInfo(List<Complaint> complaints) {
        System.out.println("Enriching " + complaints.size() + " complaints with user info");
        for (Complaint complaint : complaints) {
            System.out.println("Looking up user for complaint userId: " + complaint.getUserId());
            Optional<User> user = userRepository.findByConsumerId(complaint.getUserId());
            if (user.isPresent()) {
                System.out.println("Found user: " + user.get().getCustomerName());
                complaint.setCustomerName(user.get().getCustomerName());
                complaint.setUsername(user.get().getUsername());
            } else {
                System.out.println("No user found for userId: " + complaint.getUserId());
            }
        }
    }

    @Override
    @Transactional
    public Complaint updateComplaintStatus(Long complaintId, String status) {
        Complaint complaint = complaintRepository.findById(complaintId)
            .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setStatus(status);
        return complaintRepository.save(complaint);
    }

    @Override
    @Transactional
    public Complaint updateComplaintPriority(Long complaintId, String priority) {
        Complaint complaint = complaintRepository.findById(complaintId)
            .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setPriority(priority);
        return complaintRepository.save(complaint);
    }

    @Override
    @Transactional
    public Complaint assignEngineer(Long complaintId, String engineerId) {
        Complaint complaint = complaintRepository.findById(complaintId)
            .orElseThrow(() -> new RuntimeException("Complaint not found"));
        complaint.setAssignedTo(engineerId);
        return complaintRepository.save(complaint);
    }

    @Override
    public void deleteComplaint(Long complaintId) {
        complaintRepository.deleteById(complaintId);
    }
} 