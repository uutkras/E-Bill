package com.tcs.admin.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.List;

@Data
@Entity
@Table(name = "payments")
@NoArgsConstructor
@AllArgsConstructor
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String paymentId;
    private String billId;
    private String userId;
    private String customerName;
    private BigDecimal amount;
    private LocalDateTime paymentDate;
    private String paymentMethod;
    private String transactionId;
    private String status; // PENDING, COMPLETED, FAILED, REFUNDED
    private String remarks;
    private LocalDateTime createdAt;
    private LocalDateTime lastUpdated;

    @ElementCollection
    @CollectionTable(name = "payment_history", joinColumns = @JoinColumn(name = "payment_id"))
    @Column(name = "history_entry")
    private List<String> paymentHistory;
}