package com.tcs.complaint_service.controller;

import com.tcs.complaint_service.model.Complaint;
import com.tcs.complaint_service.model.ComplaintStatus;
import com.tcs.complaint_service.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/complaints")
@CrossOrigin(origins = "*")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @PostMapping
    public ResponseEntity<Complaint> createComplaint(@RequestBody Map<String, String> request) {
        Complaint complaint = complaintService.createComplaint(
            request.get("userId"),
            request.get("userName"),
            request.get("billNumber"),
            request.get("mobileNumber"),
            request.get("address"),
            request.get("complaintType"),
            request.get("subType"),
            request.get("problemTitle"),
            request.get("problemDescription")
        );
        return ResponseEntity.ok(complaint);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Complaint>> getComplaintsByUser(@PathVariable String userId) {
        return ResponseEntity.ok(complaintService.getComplaintsByUserId(userId));
    }

    @GetMapping
    public ResponseEntity<List<Complaint>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @PatchMapping("/{complaintId}/status")
    public ResponseEntity<Complaint> updateComplaintStatus(
            @PathVariable Long complaintId,
            @RequestBody Map<String, String> request) {
        ComplaintStatus newStatus = ComplaintStatus.valueOf(request.get("status").toUpperCase().replace(" ", "_"));
        return ResponseEntity.ok(complaintService.updateComplaintStatus(complaintId, newStatus));
    }

    @PostMapping("/{complaintId}/comments")
    public ResponseEntity<Complaint> addComment(
            @PathVariable Long complaintId,
            @RequestBody Map<String, String> request) {
        return ResponseEntity.ok(complaintService.addComment(complaintId, request.get("comment")));
    }

    @DeleteMapping("/{complaintId}")
    public ResponseEntity<Void> deleteComplaint(@PathVariable Long complaintId) {
        complaintService.deleteComplaint(complaintId);
        return ResponseEntity.ok().build();
    }
} 