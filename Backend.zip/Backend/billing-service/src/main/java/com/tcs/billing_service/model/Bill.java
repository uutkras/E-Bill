package com.tcs.billing_service.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.math.BigDecimal;

@Entity
@Table(name = "bills")
public class Bill {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String consumerId;
    private String userId;
    private BigDecimal amount;
    private LocalDate billDate;
    private LocalDate dueDate;
    private String status; // PAID, UNPAID
    private Integer unitsConsumed;
    private BigDecimal ratePerUnit;

    // Default constructor
    public Bill() {}

    // Constructor for generating random bills
    public Bill(String consumerId, String userId, LocalDate billDate) {
        this.consumerId = consumerId;
        this.userId = userId;
        this.billDate = billDate;
        this.dueDate = billDate.plusDays(30);
        this.unitsConsumed = (int) (Math.random() * 500) + 100; // Random units between 100-600
        this.ratePerUnit = new BigDecimal("8.50"); // Fixed rate per unit
        this.amount = this.ratePerUnit.multiply(BigDecimal.valueOf(this.unitsConsumed));
        this.status = "UNPAID";
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getConsumerId() {
        return consumerId;
    }

    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public LocalDate getBillDate() {
        return billDate;
    }

    public void setBillDate(LocalDate billDate) {
        this.billDate = billDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(Integer unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

    public BigDecimal getRatePerUnit() {
        return ratePerUnit;
    }

    public void setRatePerUnit(BigDecimal ratePerUnit) {
        this.ratePerUnit = ratePerUnit;
    }
} 